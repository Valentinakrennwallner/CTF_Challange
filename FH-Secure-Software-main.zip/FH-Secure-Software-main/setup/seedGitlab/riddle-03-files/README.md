# Riddle 3

## Programmiersprache: C

Sogar ein Bild Upload kann Fehler enthalten.

Bitte nur file.c bearbeiten.





Hint: R2Vuw7xndCBlaW5lIEJsYWNrbGlzdCB3aXJrbGljaCBmw7xyIEJpbGRlcj8=