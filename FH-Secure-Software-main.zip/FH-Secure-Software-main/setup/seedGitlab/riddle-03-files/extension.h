#ifndef EXTENSION_H
#define EXTENSION_H

int processImageUpload(const char* filename, long file_size_bytes);

#endif