# Riddle 2

## Programmiersprache: Rust

Beim Speichern von Credentials in der Datenbank entstehen oft Fehler.
Auch dieses Riddle ist noch leicht zu lösen.