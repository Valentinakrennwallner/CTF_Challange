public enum Role {
    USER,
    ADMIN
}