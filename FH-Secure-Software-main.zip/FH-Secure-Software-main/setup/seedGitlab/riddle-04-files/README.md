# Riddle 4

## Programmiersprache: Java

Mit mehreren Dateien wird es schon schwieriger. 
Wenn ihr diesen Fehler beheben könnt, habt ihr das letzte Riddle gemeistert.






Hint: U29sbHRlIGVpbiBub3JtYWxlciBVc2VyIGRhcyB3aXJrbGljaCBtYWNoZW4gZMO8cmZlbj8=