# Riddle 1

## Programmiersprache: Python

Nun wird euer wissen tatsächlich geprüft. Könnt ihr den Security Fehler finden der sich in dieser Datei befindet?
Bitte nur config_writer.py bearbeiten.

In diesem Programm wird eine Konfigurationsdatei mit sensiblen Daten erstellt.
Auch wenn der Fehler schnell zu lösen ist, hat er trotzdem große Konsequenzen.

Die Datei kann direkt in GitLab editiert werden.
Dazu Datei anklicken, Edit, Edit single file. 
Edit in Web IDE geht nicht.

Nach dem bearbeiten rechts oben auf Commit changes klicken.
Wenn es erfolgreich gelöst wurde, findet man neben dem riddle-01 auch das riddle-02 Project.

### Reminder:
1. Fehler finden
2. Fehler beheben
3. Commit
4. Positiver Test = Freischaltung von Riddle 2